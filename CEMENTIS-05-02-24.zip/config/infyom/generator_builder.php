<?php

return [

    'views' => [

        'builder' => 'generator-builder::builder',

        'field-template' => 'generator-builder::field-template',

        'relation-field-template' => 'generator-builder::relation-field-template'
    ]
];