<?php
return [
    'en' => [
        'display' => 'English',
        'flag-icon' => 'us'
    ]
];
