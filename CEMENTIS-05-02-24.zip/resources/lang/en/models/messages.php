<?php

return array (
  'singular' => 'Message',
  'plural' => 'Messages',
  'fields' => 
  array (
    'id' => 'Id',
    'contenu' => 'Contenu',
    'destinataire' => 'Destinataire',
    'api' => 'Api',
  ),
);
