<?php

return array (
  'singular' => 'FileUpload',
  'plural' => 'FileUploads',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
    'file_upload' => 'File Upload',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
