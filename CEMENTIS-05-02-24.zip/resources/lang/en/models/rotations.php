<?php

return array (
  'singular' => 'Rotation',
  'plural' => 'Rotations',
  'fields' => 
  array (
    'id' => 'Id',
    'imei' => 'Imei',
    'type' => 'Type',
    'date_heure' => 'Date et heure',
    'description' => 'Description',
    'vehicule' => 'Véhicule',
    'latitude' => 'Latitude',
    'longitude' => 'Longitude',
  ),
);
