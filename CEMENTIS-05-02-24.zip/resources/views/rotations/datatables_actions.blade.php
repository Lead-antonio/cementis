
<div class='btn-group'>
    <a href="{{ route('rotations.show', $id) }}" class='btn btn-primary btn-xs'>
        <i class="fa fa-eye"></i>
    </a>
    {{-- <a href="{{ route('rotations.edit', $id) }}" class='btn btn-default btn-xs'>
        <i class="fa fa-edit"></i>
    </a> --}}

</div>
